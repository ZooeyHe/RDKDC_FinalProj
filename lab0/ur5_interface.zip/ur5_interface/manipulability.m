function mu = manipulability(J, measure)
if measure == 'sigmamin'
    e = eig(J'*J);
    mu = sqrt(min(e));
elseif measure == 'detjac'
    mu = det(J);
elseif measure == 'invcond'
    e = eig(J'*J);
    mu = sqrt(min(e))/sqrt(max(e));
end
end