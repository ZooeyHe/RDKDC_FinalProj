function Jb = ur5BodyJacobian(ths)
L1 = 0.425;
L2 = 0.392;
L3 = 0.1093;
L4 = 0.09475;
L5 = 0.0825;
xi1  = [cross(-[0,0,1],[0,0,0])'; [0,0,1]'];
xi2  = [cross(-[1,0,0],[0,0,0])'; [1,0,0]'];
xi3  = [cross(-[1,0,0],[0,0,L1])'; [1,0,0]'];
xi4  = [cross(-[1,0,0],[0,0,L1+L2])'; [1,0,0]'];
xi5  = [cross(-[0,0,1],[L3,0,0])'; [0,0,1]'];
xi6  = [cross(-[1,0,0],[0,0,L1+L2+L4])'; [1,0,0]'];
gst0 = [eye(3), [L3+L5 0 L1+L2+L4]'; [0 0 0 1]];

xi1t = adinv(exptwist(xi1,ths(1))*exptwist(xi2,ths(2))*exptwist(xi3,ths(3))*exptwist(xi4,ths(4))*exptwist(xi5,ths(5))*exptwist(xi6,ths(6))*gst0)*xi1;
xi2t = adinv(exptwist(xi2,ths(2))*exptwist(xi3,ths(3))*exptwist(xi4,ths(4))*exptwist(xi5,ths(5))*exptwist(xi6,ths(6))*gst0)*xi2;
xi3t = adinv(exptwist(xi3,ths(3))*exptwist(xi4,ths(4))*exptwist(xi5,ths(5))*exptwist(xi6,ths(6))*gst0)*xi3;
xi4t = adinv(exptwist(xi4,ths(4))*exptwist(xi5,ths(5))*exptwist(xi6,ths(6))*gst0)*xi4;
xi5t = adinv(exptwist(xi5,ths(5))*exptwist(xi6,ths(6))*gst0)*xi5;
xi6t = adinv(exptwist(xi6,ths(6))*gst0)*xi6;

Jb = [xi1t, xi2t, xi3t, xi4t, xi5t, xi6t];
end